#pragma once
#include <vector>
#include "Button.h"
#include "SDL.h"
using namespace std;

enum changeOp { none, change, pause, resume, };

class State
{
protected:
	SDL_Renderer* m_pR;
	State* m_pChangeTo;
	changeOp m_eChangeOp;
	State();
public:
	virtual void Enter() = 0;
	virtual void Resume() = 0; // Used for pause.
	virtual void HandleEvents() = 0;
	virtual void Update() = 0;
	virtual void Render() = 0;
	virtual void Exit() = 0;
	State* GetChangeTo() { return m_pChangeTo; }
	changeOp GetChangeOp() { return m_eChangeOp; }
};

class GameState : public State
{
public:
	GameState() {}
	void Enter();
	void Resume();
	void HandleEvents();
	void Update();
	void Render();
	void Exit();
};

class TitleState : public State
{
private:
	vector<Button*> m_vButtons;
public:
	enum btn { play, exit };
	TitleState() {}
	void Enter();
	void Resume() {};
	void HandleEvents();
	void Update();
	void Render();
	void Exit();

};

class PauseState : public State
{
public:
	PauseState() {}
	void Enter();
	void Resume() {};
	void HandleEvents();
	void Update();
	void Render();
	void Exit();
};

class FSM
{
private:
	State* m_pCurrentState;
	State* m_pLastState;
public:
	FSM() :m_pCurrentState(nullptr), m_pLastState(nullptr)
	{
		ChangeState(new TitleState());
	}
	void Update();
	void Render();
	void ChangeState(State* changeTo);
	void Clean();
};
