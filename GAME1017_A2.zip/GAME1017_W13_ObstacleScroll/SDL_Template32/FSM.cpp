#include <iostream>
#include "FSM.h"
#include "Game.h"
using namespace std;

State::State() :m_pR(Game::Instance()->GetRenderer()), m_pChangeTo(nullptr), m_eChangeOp(none) {}

void State::Render()
{
	SDL_RenderPresent(m_pR);
}

// Begin GameState.
void GameState::Enter()
{
	cout << "Entering game..." << endl;
}

void GameState::Resume()
{
	m_eChangeOp = none;
	cout << "Resuming game..." << endl;
}

void GameState::HandleEvents()
{
	if (Game::Instance()->KeyDown(SDL_SCANCODE_X))
	{
		m_eChangeOp = change;
		m_pChangeTo = new TitleState;

	}
	if (Game::Instance()->KeyDown(SDL_SCANCODE_P))
	{
		m_eChangeOp = pause;
		m_pChangeTo = new PauseState;
	}
}

void GameState::Update()
{
	this->HandleEvents();
	// Stuff. Game goes here.
}

void GameState::Render()
{
	//SDL_SetRenderDrawColor(m_pR, 186, 218, 55, 255);
	//SDL_RenderClear(m_pR);
	// Stuff.
	//State::Render();
}

void GameState::Exit()
{
	cout << "Exiting game..." << endl;
}
// End GameState.

// Begin TitleState.
void TitleState::Enter()
{
	cout << "Entering title..." << endl;
	m_vButtons.push_back(new Button("Img/button.png", { 312,100,400,100 }));
	m_vButtons.push_back(new Button("Img/exit.png", { 312,300,400,100 }));
}

void TitleState::HandleEvents()
{
	// Parse buttons.
	if (m_vButtons[btn::play]->Clicked())
	{
		// Have next two lines if you want to see button in its down state. 
		this->Render();
		SDL_Delay(100);
		// Then change state.
		m_eChangeOp = change;
		m_pChangeTo = new GameState;
	}
	else if (m_vButtons[btn::exit]->Clicked())
	{
		this->Render();
		SDL_Delay(100);

		Game::Instance()->Quit();
	}
}

void TitleState::Update()
{
	for (int i = 0; i < (int)m_vButtons.size(); i++)
		m_vButtons[i]->Update();
	this->HandleEvents();
}

void TitleState::Render()
{
	SDL_SetRenderDrawColor(m_pR, 128, 128, 255, 255);
	SDL_RenderClear(m_pR);
	// Stuff.
	for (int i = 0; i < (int)m_vButtons.size(); i++)
		m_vButtons[i]->Render();
	State::Render();
}

void TitleState::Exit()
{
	cout << "Exiting title..." << endl;
	for (unsigned i = 0; i < m_vButtons.size(); i++) // size() returns an unsigned type.
	{
		delete m_vButtons[i];
		m_vButtons[i] = nullptr;
	}
	m_vButtons.clear();
	m_vButtons.shrink_to_fit();
}
// End TitleState.

// Begin PauseState.
void PauseState::Enter()
{
	cout << "Entering pause..." << endl;
}

void PauseState::HandleEvents()
{
	if (Game::Instance()->KeyDown(SDL_SCANCODE_R))
	{
		m_eChangeOp = resume;
		m_pChangeTo = nullptr;
	}
}

void PauseState::Update()
{
	this->HandleEvents();
}

void PauseState::Render()
{
	SDL_SetRenderDrawColor(m_pR, 255, 128, 128, 255);
	SDL_RenderClear(m_pR);
	// Stuff.
	State::Render();
}

void PauseState::Exit()
{

}
// End TitleState.

// Begin state machine.

// End state machine.

void FSM::Update()
{
	m_pCurrentState->Update();
	if (m_pCurrentState->GetChangeOp() == resume)
	{
		cout << "Resuming last state..." << endl;
		ChangeState(m_pLastState);

	}
	else if (m_pCurrentState->GetChangeOp() != none)
	{
		cout << "Changing states..." << endl;
		ChangeState(m_pCurrentState->GetChangeTo());
	}
}

void FSM::Render()
{
	m_pCurrentState->Render();
}

void FSM::ChangeState(State* changeTo)
{
	if (changeTo == nullptr) // If the state we want to change to is null.
		return;
	if (m_pCurrentState != nullptr && m_pCurrentState->GetChangeOp() != pause)
		m_pCurrentState->Exit();
	if (m_pCurrentState != nullptr && m_pCurrentState->GetChangeOp() == resume)
		changeTo->Resume();
	else
	{
		if (m_pLastState != nullptr)
			delete m_pLastState; // Delete old last state.
		changeTo->Enter();
	}
	m_pLastState = m_pCurrentState;
	m_pCurrentState = changeTo;
}

void FSM::Clean()
{
	if (m_pCurrentState != nullptr)
		delete m_pCurrentState;
	if (m_pLastState != nullptr)
		delete m_pLastState;
}
